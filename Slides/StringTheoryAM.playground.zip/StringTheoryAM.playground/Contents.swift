import UIKit
/*
var str = "Hello, playground"
str += "!"

var str2 = """
I think that I
shall never see
a poem
lovely
as a tree
"""
print(str2)

var str3 = "Hello\t \\ \n \"really\""
print(str3)

var str4 = "hello \u{1F330}"

var str5 = "Hello, Miller"
var str6 = str5
str5 += "!"
print(str6)

for ch in str5 {
    print(ch, terminator:"")
    if ch == "o" {
        print("Hey, I found an \"o\"")
    }
}

let ch:Character = "F"
let ch2 = "G"

let eAcute:Character = "\u{E9}"
let combined:Character = "\u{65}\u{301}"

var place = "cafe"
print(place.count)

place += "\u{301}"

print(place, place.count)

var start = "hello"
var happy:Character = "!"

// start += happy

start.append(happy)
start.append("!")

start.isEmpty
start.count

*/
var message = "Hello and welcome!"
message[message.startIndex]
// message[message.endIndex]
var loc = message.index(before:message.endIndex)
message[loc]

loc = message.index(after:message.startIndex)
message[loc]

loc = message.index(message.startIndex, offsetBy:4)
message[loc]
// var message = "Hello and welcome!"
for i in stride(from:0, to:message.count, by:2){
    loc = message.index(message.startIndex, offsetBy:i)
    print(message[loc], terminator:"-")
}
print("Break")
for i in 0 ..< message.count / 2 {
    loc = message.index(message.startIndex,offsetBy:2*i)
    print(message[loc], terminator:"-")
}
print(message.endIndex.encodedOffset)

message = "Hello, world!"
let val = message.index(of:"o")

message.contains("world")
let loLocation = message.range(of:"lo")
loLocation!.lowerBound.encodedOffset
loLocation!.upperBound.encodedOffset

// loLocation = message.range(of:"behold")

message.hasPrefix("hello")
message.hasSuffix("ld!")
message.insert("x", at:message.index(message.startIndex,offsetBy:5))
message.insert("y", at:message.index(of:",")!)
message.insert(contentsOf:"out there", at:message.startIndex)

// starting with "Hello, world"
// remove the ,
// insert "people of the" where the , used to be

message = "Hello, world"
message.remove(at:message.index(of:",")!)
message.insert(contentsOf:" people of the", at:message.index(message.startIndex,offsetBy:5))
message
