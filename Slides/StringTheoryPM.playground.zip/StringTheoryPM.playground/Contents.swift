import UIKit

var str = "Hello, playground"
let str2 = "You Shall Not Pass"

var str3 = """
I \"think\" that I
\t shall never see
\\a poem lovely\n
as a
tree \u{1F332}
"""
print(str3)

// strings are value types struct String
var str4 = "Remember the Cant"
var str5 = str4
str4 += "!!!"
print(str5)

for ch in str4 {
    print(ch, terminator:"")
}

var gender = "F"
var gender2:Character = "F"

let eAcute:Character = "\u{E9}"
let combinedAcute:Character = "\u{65}\u{301}"

var word = "cafe"
print(word.count)
word += "\u{301}"
print(word.count)

var start = "We shall"
var end = " fight on the beaches"

var quote = start + end

quote += "!!!"

var ch:Character = "?"
//quote += ch

quote += String(ch)
quote.append(ch)

"".isEmpty
var phrase = "Swift Rules!"
phrase[phrase.startIndex]
//phrase[phrase.endIndex]

var loc = phrase.index(after:phrase.startIndex)
phrase [loc]
loc = phrase.index(after:loc)
phrase[loc]
loc = phrase.index(before:phrase.endIndex)
phrase[loc]

loc = phrase.index(phrase.endIndex,offsetBy:-3)
phrase[loc]

// print out the even characters of phrase, all on one line

for i in stride(from:0, to:phrase.count, by:2){
    loc = phrase.index(phrase.startIndex,offsetBy:i)
    
    print(phrase[loc])
}

print(phrase.index(phrase.startIndex,offsetBy:4).encodedOffset)
